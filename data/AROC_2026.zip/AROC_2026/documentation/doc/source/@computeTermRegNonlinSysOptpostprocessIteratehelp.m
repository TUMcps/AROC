%% postprocessIterate
% post-processing of the convex/polynomial programming
% solution.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [sol,costCoeffNext,costSetNext] = postprocessIterate(obj,sCost,slack,tr_exploit,estAbsErr,solverTime,setupTime) <br>
%        </div>
% </html>
%
%% Description
% The post-processing of the optimal solution consists of the
% following steps:
% - checking feasibility
% - computation of the volume of the (under-approxmiation) of the
% candidate terminal region (required for checking convergence)
% - updating the coefficients of the cost function for the next
% iteration
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysOpt
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            sCost
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            generator scaling factors for obj.costSet
%            (double vector)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            slack
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            vector collecting all slack variables
%            (double vector)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            tr_exploit
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            scalar indicating the exploitation of the trust
%            region
%            (scalar, 0 <= tr_exploit <= 1)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            estAbsErr
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            estimate of the set of abstraction errors
%            (class: interval)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            solverTime
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            time for solving the optimization problem
%            (positive scalar)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            setupTime
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            time for setting up the optimization problem
%            (positive scalar)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            updated instance of class
%            computeTermRegNonlinSysOpt
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            auxData
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            additional solution data (e.g. flag indicating;
%            feasibility)
%            (class: termRegNonlinSysSolutionAuxData)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('-') ->
%
%% References
% [1] L. Schäfer et al. "Scalable Computation of Robust Control
% Invariant Sets of Nonlinear Systems", in IEEE Transactions
% on Automatic Control, vol. 69, no. 2, pp. 755-770, 2024
% [2] L. Schäfer and M. Althoff, "Computing Robust Control Invariant
% Sets of Nonlinear Systems Using Polynomial Controller
% Synthesis," American Control Conference, 2024, pp. 4162-4169.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
