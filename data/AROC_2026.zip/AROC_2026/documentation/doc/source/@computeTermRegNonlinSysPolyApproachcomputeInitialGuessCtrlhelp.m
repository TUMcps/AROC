%% computeInitialGuessCtrl
% computation of an initial guess for the controller
% parameters.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% p0 = computeInitialGuessCtrl(obj,dynamics,candTermReg) <br>
%        </div>
% </html>
%
%% Description
% This function computes an initial guess for the controller
% parameters by solving a based on the controller synthesis approach
% from [2]. To enable the algorithm to recover feasibility faster,
% the goal is to steer all states of the candidate terminal region
% back into this set with minimum control effort (encoded as the
% exploitation of set of admissible inputs). To formulate a convex
% program, we only cosider the linear abstraction of the dynamics.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysPolyApproach
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dynamics
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class termRegNonlinSysDynamics
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            candTermReg
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            initial guess for the terminal region
%            (class: polyZonotope)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             p0
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            initial guess for the controller parameters
%            (double array of dimension [length(obj.id.p),1])
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('@computeTermRegNonlinSysPolyApproach/computeInitialGuess') @computeTermRegNonlinSysPolyApproach/computeInitialGuess>
%
%% References
% [1] L. Schäfer and M. Althoff, "Computing Robust Control Invariant
% Sets of Nonlinear Systems Using Polynomial Controller
% Synthesis," American Control Conference, 2024, pp. 4162-4169.
% [2] B. Schürmann and M. Althoff, "Guaranteeing Constraints of
% Disturbed Nonlinear Systems Using Set-Based Optimal Control in
% Generator Space,", IFAC-PapersOnLine, Volume 50, Issue 1, 2017,
% pp. 11515-11522.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
