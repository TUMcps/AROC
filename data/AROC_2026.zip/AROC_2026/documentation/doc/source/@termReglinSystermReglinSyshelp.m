%% termReglinSys
% terminal region object computed with the approaches
% proposed in [1] and [2]
%
%% Syntax
%
% <html>
%        <div class="syntax">
% obj = termReglinSys(dynamics, termReg, termReg_zono, termRegState, termRegState_zono, termSet, Rtp, R, s, termRegCtrl, debug, runtimes, optsInternal) <br>
%        </div>
% </html>
%
%% Description
% This class represents a terminal region computed with the
% approach in [1] and [2].
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dynamics
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            function handle to the dynamic function of the open
%            loop system
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             termReg
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            terminal region (class: zonotope or ellipsoid)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             termReg_zono
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            zonotopic terminal region
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             termRegState
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            terminal region of the state (class: zonotope or;
%            ellipsoid)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             termRegState_zono
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            zonotopic terminal region of the state
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             termSet
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            terminal safe set, for the <tt>'fixed'</tt> approach
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             Rtp
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            over-approximations of the reachable set at time
%            steps i * Opts.timeStep, for i=0,...,Opts.N
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             R
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            over-approximation of the reachable set of termReg,
%            assuming each point is steered using the control
%            inputs from termRegCtrl
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             s
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            value of the initial stretching factors
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             termRegCtrl
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set-based safety-presevering controller
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             runtimes
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct containing information about the runtimes of
%            the different parts of the algorithm
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             optsInternal
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            a structure containing internal algorithm settings
%            See ./src/cLS_setOptsInternal
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            resulting object of class termRegContainmentLinSys
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <terminalRegionhelp.html |terminalRegion|>, <computeTermRegNonlinSysLinApproachhelp.html |computeTermRegNonlinSysLinApproach|>
%
%% References
% * *[1] "Approximability of the Containment Problem for Zonotopes
% and Ellipsotopes", A. Kulmburg et al., submited to TAC
% in 2024
% * *[2] Gruber et al. (2021)*, Computing safe sets of linear
% sampled-data systems, IEEE Control Syst. Lett., vol. 5,
% no. 2, pp. 385-390
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
