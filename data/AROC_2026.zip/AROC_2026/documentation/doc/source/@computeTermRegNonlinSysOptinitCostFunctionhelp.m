%% initCostFunction
% computes the coefficients of the cost function using
% the intial guess for the terminal region.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% obj = initCostFunction(obj,initialGuessSet) <br>
%        </div>
% </html>
%
%% Description
% This function computes the coefficients of the cost function
% (approximation of the volume of the terminal region) using the
% intial guess for the terminal region. If the number of coefficients
% exceeds a given threhold, a set of reduced order that is contained
% in the terminal region is computed, which will be used to obtain an
% underapproximation of the cost function value (see [1, Remark 2]).
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysOpt
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            initialGuessSet
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            initial guess for the terminal region
%            (class: zonotope)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            updated instance of class
%            computeTermRegNonlinSysOpt
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('-') ->
%
%% References
% [1] L. Schäfer et al. "Scalable Computation of Robust Control
% Invariant Sets of Nonlinear Systems", 2024, IEEE Transactions
% on Automatic Control
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
