%% computeTermRegNonlinSysOpt
% abstract superclass for
% optimization-based approaches for computing terminal regions of
% nonlinear systems.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% obj = computeTermRegNonlinSysOpt(X,U,W,xEq,uEq,termRegOrder) <br>
% obj = computeTermRegNonlinSysOpt(X,U,W,xEq,uEq,termRegOrder,solverSettings) <br>
%        </div>
% </html>
%
%% Description
% This class and its childclasses provide all methods required
% for formulating and solving the convex [1] or polynomial [2]
% approximations of the terminal region optimization problem in
% [2, Eq. (6)] as well as the methods for verifying correctness
% of the candidate solutions.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            X
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of admissible states
%            (class: interval / polytope / zonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            U
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of admissible control inputs
%            (class: interval / polytope / zonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            W
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of uncertain disturbances
%            (class: zonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            xEq
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            equilibrium state
%            (array of dimension [X.dim,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            uEq
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            equilibrium control input
%            (array of dimension [U.dim,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            termRegOrder
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            order of the zonotope representing the
%            terminal region
%            (positive integer)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            verbose
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            if set to true, the algorithm prints
%            information about each iteration to the
%            command window. If set to false, no
%            iterative output is shown.
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            solverSettings
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            (optional) struct with the following
%            optional fields
%        </p>
%        <p class="table">
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="inner">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .penaltyWeight
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            penalty weight for soft
%            constraints, see [1, Remark 4]
%            (positive scalar)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .convergenceTolerance
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            convergence tolerance, see
%            [1, Eq. 18]
%            (positive scalar)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .constraintTolerance
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            constraint tolerance
%            (positive scalar)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .maxIter
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            max. number of iterations
%            (positive integer)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .maxCostTerms
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            maximum admissible number of
%            addends in the cost function,
%            see [1, Remark 2]
%            (positive interger)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .tr_maxRelErr
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            max. relative approximation
%            error (see [1, App. II])
%            (0 < tr_malRelErr < 1)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .tr_shrink
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            scaling factor for shrinking
%            the trust region (see;
%            [1, App. II])
%            (0 < tr_shrink < 1)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .tr_grow
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            scaling factor for enlarging
%            the trust region (see;
%            [1, App. II])
%            (1 < tr_grow)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            generated instance of the class
%            computeTermRegNonlinSysOpt
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('-') ->
%
%% References
% [1] L. Schäfer et al. "Scalable Computation of Robust Control
% Invariant Sets of Nonlinear Systems", in IEEE Transactions
% on Automatic Control, vol. 69, no. 2, pp. 755-770, 2024
% [2] L. Schäfer and M. Althoff, "Computing Robust Control
% Invariant Sets of Nonlinear Systems Using Polynomial
% Controller Synthesis," American Control Conference, 2024,
% pp. 4162-4169.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
