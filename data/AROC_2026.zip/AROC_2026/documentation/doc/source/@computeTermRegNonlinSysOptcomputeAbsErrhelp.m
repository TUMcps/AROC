%% computeAbsErr
% computes the abstraction error for a given
% nonlinear dynamical system and a given terminal region.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% absErr = computeAbsErr(obj,dynamics,termRegSet) <br>
%        </div>
% </html>
%
%% Description
% This function computes the abstraction error or a given
% nonlinear dynamical system over a given terminal region based on
% linearization- [1] or polymonialization-based [2] reachability
% algorithms.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class computeTermRegNonlinSysOpt
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dynamics
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class termRegNonlinSysDynamics
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            termRegSet
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            candidate for the terminal region
%            (class: zonotope/polyZonotope)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            absErr
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of abstraction errors
%            (class: interval)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('-') ->
%
%% References
% [1] M. Althoff et al., "Reachability Analysis of Nonlinear Systems
% with Uncertain Parameters using Conservative Linearization",
% IEEE Conference on Decision and Control, 2008, pp. 4042-4048.
% [2] Matthias Althoff, "Reachability analysis of nonlinear systems
% using conservative polynomialization and non-convex sets",
% International conference on Hybrid systems: computation and
% control, 2013, pp. 173–182.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
