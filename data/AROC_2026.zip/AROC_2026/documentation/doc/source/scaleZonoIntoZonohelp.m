%% scaleZonoIntoZono
% computes the biggest scaling factor so that the
% uniformly scaled candInbody is contained in circumbody.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% scale = scaleZonoIntoZono(candInbody,circumbody) <br>
%        </div>
% </html>
%
%% Description
% This function computes the biggest scaling factor alpha so that the
% uniformly scaled candInbody (the center is fixed) is still
% contained in circumbody, i.e.,
% zonotope(candInbody.c,candInbody.G*alpha) \subseteq
% zonotope(circumbody.c,circumbody.G).
% The containment problem is encoded using the sufficient conditions
% in [1, Corollary 4].
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             candInbody
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set to be contained
%            (class: zonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             circumbody
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set to contain the scaled set candInbody
%            (class: zonotope)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             scale
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            scaling factors for the generators of candInbody
%            (positive scalar)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <terminalRegionhelp.html |terminalRegion|>, <termRegNonlinSysLinApproachhelp.html |termRegNonlinSysLinApproach|>
%
%% References
% [1] S. Sadraddini and R. Tedrake, "Linear Encodings for Polytope
% Containment Problems," IEEE Conference on Decision and Control,
% 2019, pp. 4367-4372.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
