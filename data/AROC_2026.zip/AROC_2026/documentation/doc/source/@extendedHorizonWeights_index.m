%% @extendedHorizonWeights

%% Files
%
% * <.\@extendedHorizonWeightscomputeWeightsFallhelp.html |computeWeightsFall|>
% * <.\@extendedHorizonWeightscomputeWeightsFallEqDiffhelp.html |computeWeightsFallEqDiff|>
% * <.\@extendedHorizonWeightscomputeWeightsFallEqDiffFinalhelp.html |computeWeightsFallEqDiffFinal|>
% * <.\@extendedHorizonWeightscomputeWeightsFallFinalhelp.html |computeWeightsFallFinal|>
% * <.\@extendedHorizonWeightscomputeWeightsFallLinearhelp.html |computeWeightsFallLinear|>
% * <.\@extendedHorizonWeightscomputeWeightsFallLinearFinalhelp.html |computeWeightsFallLinearFinal|>
% * <.\@extendedHorizonWeightscomputeWeightsQuadhelp.html |computeWeightsQuad|>
% * <.\@extendedHorizonWeightscomputeWeightsRisehelp.html |computeWeightsRise|>
% * <.\@extendedHorizonWeightscomputeWeightsRiseEqDiffhelp.html |computeWeightsRiseEqDiff|>
% * <.\@extendedHorizonWeightscomputeWeightsRiseLinearhelp.html |computeWeightsRiseLinear|>
% * <.\@extendedHorizonWeightsextendedHorizonWeightshelp.html |extendedHorizonWeights|>

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
