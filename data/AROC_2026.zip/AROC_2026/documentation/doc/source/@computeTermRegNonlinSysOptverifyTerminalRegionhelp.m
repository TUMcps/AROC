%% verifyTerminalRegion
% verifies invariance of the terminal region.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [flagVerified,termReg_verified] = verifyTerminalRegion(obj,dynamics,termReg) <br>
%        </div>
% </html>
%
%% Description
% This function implements the verification procedure described in
% [1, Sec. III 2]. Compared to the paper, we make the following
% modification to deal with violations of the time-interval
% constraint in [1, Eq. (6b)]: we tighten the polytope, which
% represents the set of admissible states, in every direction in
% which the containment condition is violated. The tightening is
% chosen as the difference of the support function of the reachable
% set in the violating direction A(j,:) and b(j).
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysOpt
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dynamics
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class termRegNonlinSysDynamics
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            termReg
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            converged solution
%            (class: termRegNonlinSysOpt)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            flagVerified
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            true if the verification was succesful, false
%            otherwise
%            (logical)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            termReg_verified
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            verified terminal region
%            (class: termRegNonlinSysOpt)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('@computeTermRegNonlinSysOpt/checkInvariance') @computeTermRegNonlinSysOpt/checkInvariance>
%
%% References
% [1] L. Schäfer et al. "Scalable Computation of Robust Control
% Invariant Sets of Nonlinear Systems", in IEEE Transactions
% on Automatic Control, vol. 69, no. 2, pp. 755-770, 2024.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
