%% optimizeRCIpoly
% solves the polynomial programming approximation of the
% terminal region computation problem.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [sol,fVal] = optimizeRCIpoly(obj,termReg,approx_R,mapsParamReduce,paramAbsErr_coefficients,p0) <br>
%        </div>
% </html>
%
%% Description
% This function models and solves the polynomial programming
% approximation in [1, Eq. (19)] of the optimization problem in
% [1, Eq. (6)], which returns a robust control invariant set of
% a given nonlinear dynamical system with maximum volume.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysPolyApproach
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            termReg
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            initial guess for the terminal region
%            (class: polyZonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            approx_R
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            parameterized approximation of the
%            time-pointreachable set (see [1,;
%            Eq. (17)];
%            (class: polyZonotope);
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            mapsParamReduce
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the parameterization
%            of the lengths of the reducing
%            generators in the optimization
%            variables
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            paramAbsErr_coefficients
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the coefficients of
%            the parameterized approximation of the
%            abstraction error
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            p0
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            initial guess for the controller
%            parameters
%            (double vector)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            sol
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the solution of the polynomial
%            program
%            .p: controller parameters
%            .delta_c: translation of the terminal region center
%            .s: terminal region generator scaling factors
%            .sCost: cost set generator scaling factors
%            .sRed: reducing generator scaling factors
%            .sAbsErr: abstraction error interpolation factors
%            .exploitTR: scalar indicating the trust region
%            exploitation
%            .slack: slack variables of softened constraints
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            fVal
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            value of the nominal cost function
%            (size of sol.costSet)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('-') ->
%
%% References
% [1] L. Schäfer and M. Althoff, "Computing Robust Control Invariant
% Sets of Nonlinear Systems Using Polynomial Controller
% Synthesis," American Control Conference, 2024, pp. 4162-4169.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
