%% implicit_stateInputContainment
% sets up the containment-based constraints on
% the state and input for the containmentLinSys algorithm
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [variables, constraints] = implicit_stateInputContainment(optsInternal, containmentType, Rtp, Rti, utotal, preH, s) <br>
%        </div>
% </html>
%
%% Input Arguments
% containmentType:   Either |'ellipsoid'| or 'zonotope'
%
% Rtp:               cell array of structs describing the time-point
% solutions
%
% Rti:               cell array of structs describing the
% time-interval solutions
%
% utotal:            cell array of structs describing the input
%
% preH:              matrix multiplied to the left of Diag(s) (see
% setOptsInternal.m)
%
% s:                 scaling factors stored as sdpvar variables
%
%% Description
% This function prepares the necessary constraints needed to solve
% the optimization problem for the containmentLinSys algorithm,
% assuming one uses Yalmip.
%
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
