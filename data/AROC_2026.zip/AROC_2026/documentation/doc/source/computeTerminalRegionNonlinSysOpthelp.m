%% computeTerminalRegionNonlinSysOpt
% computes a terminal region of nonlinear systems.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% T = computeTerminalRegionNonlinSysOpt(benchmark,Param,Opts) <br>
%        </div>
% </html>
%
%% Description
% This function implements the iterative optimization-based
% algorithms for computing the terminal region of nonlinear
% sampled-data systems proposed in [1], [2], as well as the
% disrete-time version of the algorithm in [1].
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            benchmark
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            name of the considered benchmark model (see;
%            "aroc/benchmarks/...")
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Param
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            a struct containing the benchmark parameters
%            .X:         set of admissible states
%            (class: interval/zonotope/polytope)
%            .U:         set of admissible control inputs
%            (class: interval/zonotope/polytope)
%            .W:         set of disturbances
%            (class: zonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Opts
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            a struct containing the algorithm settings
%            .xEq:                   equlibrium state to be stabilized
%            (double vector)
%            .uEq:                   equilibrium control input
%            (double vector)
%            .timeStep:              sampling time
%            (positive scalar)
%            .termRegOrder:          (optional) order of the zonotope
%            representing the terminal region
%            (positive scalar, >= 1)
%            .nonlinSysTermRegAlg:   (<tt>'lin'</tt> / <tt>'poly'</tt>)
%        </p>
%        <p class="table">
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="inner">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            sysType
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            type of dynamical system, e.g.,
%            sampled-data or discrete-time system
%            (class: termRegSysType)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
%            .integrator:            (optional) integration scheme for time-
%            discretizing the dynamical system -
%            only considered if sysType == termRegSysType.DT
%            (class: discretizeDynamics)
%            .initialGuess:          (optional) struct storing parameters
%            for computing an initial guess
%            .Q:                 state weighting matrix
%            (positive-definite matrix of dimension;
%            [Param.X.dim,Param.X.dim])
%            .R:                 control input weighting matrix
%            (positive-definite matrix of dimension;
%            [Param.U.dim,Param.U.dim])
%            .weights:           struct storing the weighting factors
%            for different options for computing the
%            initial guess - valid field names:
%            <tt>'RiccatiEq'</tt>, <tt>'minRCI'</tt>, 'minRPI'
%            'bwReachInputs'
%            (non-negative scalars)
%            .verbose:               if set to true, the algorithm prints
%            information about each iteration to the
%            command window. If set to false, no
%            iterative output is shown.
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            T
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            verified solution
%            (class: termRegNonlinSysOpt)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See also
% <matlab:doc('-') ->
%
%% References
% [1] L. Schäfer et al., "Scalable Computation of Robust Control
% Invariant Sets of Nonlinear Systems", 2024, IEEE Transactions
% on Automatic Control, vol. 69, no. 2, pp. 755-770.
% [2] L. Schäfer and M. Althoff, "Computing Robust Control Invariant
% Sets of Nonlinear Systems Using Polynomial Controller
% Synthesis," American Control Conference, 2024, pp. 4162-4169.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
