%% solveOptProblem
% models and solves the polynomial programming
% approximation of the terminal region computation problem.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [obj,termReg_opt,auxData_iter] = solveOptProblem(obj,dynamics,termReg,flagInitGuessFeasible) <br>
% [obj,termReg_opt,auxData_iter] = solveOptProblem(obj,dynamics,termReg,flagInitGuessFeasible,bloatAbsErr) <br>
%        </div>
% </html>
%
%% Description
% This function models and solves the polynomial programming
% approximation in [1, Eq. (19)] of the optimization problem in
% [1, Eq. (6)], which returns a robust control invariant set of
% a given nonlinear dynamical system with maximum volume.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysPolyApproach
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dynamics
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class termRegNonlinSysDynamics
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            termReg
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            current candidate for the terminal region
%            (class: termRegNonlinSysPolyApproach)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            flagInitGuessFeasible
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            indicates whether termReg admits a feasible
%            initial guess (or not)
%            (boolean)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            bloatAbsErr
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            (optional) scaling factor for enlarging the
%            set of abstraction errors (see the;
%            verification procedure described in;
%            [2, Sec. III 2])
%            (bloatAbsErr >= 1)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            updated instance of class
%            computeTermRegNonlinSysPolyApproach
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            termReg_opt
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            updated candidate for the terminal region
%            (class: termRegNonlinSysPolyApproach)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            auxData_iter
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            additional solution data (e.g. flag indicating;
%            feasibility)
%            (class: termRegNonlinSysSolutionAuxData)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('-') ->
%
%% References
% [1] L. Schäfer and M. Althoff, "Computing Robust Control Invariant
% Sets of Nonlinear Systems Using Polynomial Controller
% Synthesis," American Control Conference, 2024, pp. 4162-4169.
% [2] L. Schäfer et al., "Scalable Computation of Robust Control
% Invariant Sets of Nonlinear Systems", 2024, IEEE Transactions
% on Automatic Control, vol. 69, no. 2, pp. 755-770.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
