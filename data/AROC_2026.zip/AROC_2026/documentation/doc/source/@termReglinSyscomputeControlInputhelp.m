%% computeControlInput
% computes the control inputs one has to choose so
% that an output y starting in the terminal region
% ends up again in the terminal region
%
%% Syntax
%
% <html>
%        <div class="syntax">
% u = computeControlInput(T, y, currentInput, nTimeStep, beta) <br>
% u = computeControlInput(T, y, currentInput, nTimeStep, beta, beta_V) <br>
%        </div>
% </html>
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            y
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            A point that lies in the terminal region of the output
%            (and for which the state lies in the state terminal;
%            region) if nTimeStep=1, and lies in the reachable set
%            of the terminal region at time
%            (nTimeStep-1) * T.Opts.timeStep
%            (class: double)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            nTimeStep
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            Index of the current time step (class: double, must be;
%            a positive integer)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            beta<br>beta_V
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            Initial parametrization of y0
%        </p>
%        <p class="table">
%             in other words, if y is
%            the current trajectory that started with y0, then beta
%            is given by
%            y0 = G_0 <b> beta + c_0 + G_V </b> beta_V
%            where G_0 and c_0 are the generator matrix and center
%            of the terminal region, G_V is the generator matrix of
%            the noise set.
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            u
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            Inputs that have to be applied at time
%            nTimeStep * T.Opts.timeStep, in order to continue
%            steering the system back to the terminal region
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Description
% Computes the control inputs one has to choose so that an output y
% starting in the terminal region ends up again in the terminal
% region.
%
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
