%% Algorithms

%% Directories
%
% * <.\combinedControl_index.html |Combined Control|>
% * <.\convexInterpolationControl_index.html |Convex Interpolation Control|>
% * <.\generatorSpaceControl_index.html |Generator Space Control|>
% * <.\linSysMPC_index.html |Lin Sys MPC|>
% * <.\optimizationBasedControl_index.html |Optimization Based Control|>
% * <.\polynomialControl_index.html |Polynomial Control|>
% * <.\reachsetMPC_index.html |Reachset MPC|>
% * <.\safetyNetControl_index.html |Safety Net Control|>

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
