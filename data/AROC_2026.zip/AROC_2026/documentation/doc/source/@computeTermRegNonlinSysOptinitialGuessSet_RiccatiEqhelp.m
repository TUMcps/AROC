%% initialGuessSet_RiccatiEq
% solves the Riccati equation for the linearized
% dynamics and inscribes a zonotope into the resulting ellipsoid.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% PIset = initialGuessSet_RiccatiEq(obj,dynamics,Q,R) <br>
%        </div>
% </html>
%
%% Description
% To obtain an initial guess for the optimization-based approaches
% for computing terminal regions of nonlinear systems, we solve the
% algebraic Riccati equation (ARE) for the linearized dynamics.
% Afterwards, a zonotope is inscribed into the positively invariant
% ellipsoid whose shape matrix is the solution of the ARE.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysOpt
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dynamics
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class termRegNonlinSysDynamics
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Q
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            state weighting matrix
%            (positive-definite matrix of dimension;
%            [obj.nx,obj.nx])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            R
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            control input weighting matrix
%            (positive-definite matrix of dimension;
%            [obj.nu,obj.nu])
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            PIset
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            approximation of the positively invariant set
%            (class: termRegNonlinSysLinApproach)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See also
% <matlab:doc('-') ->
%
%% References
% -
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
