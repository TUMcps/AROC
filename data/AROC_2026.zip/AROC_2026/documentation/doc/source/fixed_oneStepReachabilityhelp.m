%% fixed_oneStepReachability
% A variant of implicit_oneStepReachability,
% where there are no loose variables (necessary for the 'fixed'
% approach) and where U_X and U_V are set to 0. Also, we ignore Y and
% measurement noises, and only compute the state reachable set.
% Finally, we also take into account the equilibrium point.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [Rtp, Rti, ctrl_variable, utotal, additional_variables, additional_constraints] = fixed_oneStepReachability(Rtp_previous, optsInternal) <br>
%        </div>
% </html>
%
%% Description
% Computes one step of linear reachability analysis, using the
% trivial controller.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Rtp_previous
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            Struct containing the variables describing
%            the time-point solution from the previous step
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            optsInternal
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            Struct containing internal parameters
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Rtp
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            Struct containing the variables describing
%            the time-point solution
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Rti
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            Struct containing the variables describing
%            the time-interval solution
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             utotal
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            Struct containing the variables describing
%            the input
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <implicit_oneStepReachabilityhelp.html |implicit_oneStepReachability|>
%
%% References
% * *[1] "Approximability of the Containment Problem for Zonotopes
% and Ellipsotopes", A. Kulmburg et al., submited to TAC
% in 2024
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
