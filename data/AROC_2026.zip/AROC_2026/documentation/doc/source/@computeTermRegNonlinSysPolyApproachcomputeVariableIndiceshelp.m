%% computeVariableIndices
% computes the indices of the entries storing,
% e.g., the generator scaling factors in the vector of optimization
% variables.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% idxVars = computeVariableIndices(obj,id,id_redVar,nGenR,nGenTermReg,nGenCtrl,nGenU,nGenReduce,nGenErr) <br>
%        </div>
% </html>
%
%% Description
% To formulate the polynomial program in [1, Eq. (19)] in the generic
% form of a nonlinear programming problem, i.e.,
% min f(y) s.t. g(y) <= 0, h(y) = 0,
% the variables must be lumped together into a single vector y. To,
% e.g., easily extract the generator scaling factors from the optimal
% solution, this function computes the indices of the entries of y
% storing the corresponding variable.
% These indices are stored in the struct idxVars. They need to be
% recomputed in every iteration since the number of reduced
% generators and, thus, the number of variables might change in
% between iterations.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysPolyApproach
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            id
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the polynomial zonotope ids for
%            parameterized reachability analysis
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            id_redVar
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of indices indicating reducing generators with
%            variable length (in the optimization variables)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            nGenR
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            number of dependent generators of the parameterized
%            reachable set
%            (scalar)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            nGenTermReg
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            number of generators of the terminal region
%            (scalar)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            nGenCtrl
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            number of generators of the controller template
%            (scalar)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            nGenU
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            number of generators of the set of admissible
%            control inputs
%            (scalar)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            nGenReduce
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            number of reduced generators (parameterized order;
%            reduction)
%            (scalar)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            nGenErr
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            number of independent generators of the
%            parameterized reachable set
%            (scalar)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            idxVars
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the indices of the optimization
%            variables
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('@computeTermRegNonlinSysPolyApproach/optimizeRCIpoly') @computeTermRegNonlinSysPolyApproach/optimizeRCIpoly>
%
%% References
% [1] L. Schäfer and M. Althoff, "Computing Robust Control Invariant
% Sets of Nonlinear Systems Using Polynomial Controller
% Synthesis," American Control Conference, 2024, pp. 4162-4169.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
