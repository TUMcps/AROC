%% simulate
% simulate a trajectory of a terminal region controller
%
%% Syntax
%
% <html>
%        <div class="syntax">
% trajectory = simulate(obj,y0,w,v) <br>
%        </div>
% </html>
%
%% Description
% Simulate a trajectory of a linear system controlled with the
% safety-preserving controller associated with a terminal region
% computed with the linSysContainment algorithm for random initial
% points inside the terminal region and randomly drawn disturbance
% values.
%
%% Input Arguments
%
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            y0
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            initial point for simulation (class: double)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            w
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            matrix storing the values for the disturbances over time
%            (dimension: [T.optsInternal.nw,T.Opts.N])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            v
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            matrix storing the values for the measurement errors
%            over time (dimension: [T.optsInternal.nv,T.Opts.N+1])
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            trajectory
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct containing all parts of the simulated
%            trajectory, i.e., x, y, yexact, u, v, w, t
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <termRegNonlinSysLinApproachhelp.html |termRegNonlinSysLinApproach|>, <simulateRandomhelp.html |simulateRandom|>, <computeTermRegNonlinSysLinApproachhelp.html |computeTermRegNonlinSysLinApproach|>
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
