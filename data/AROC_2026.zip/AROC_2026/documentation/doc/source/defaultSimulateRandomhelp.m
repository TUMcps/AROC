%% defaultSimulateRandom
% default settings for random simulation
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [Npoints,fracVert,fracDistVert,distChanges] = defaultSimulateRandom() <br>
% [Npoints,fracVert,fracDistVert,distChanges] = defaultSimulateRandom(Npoints,fracVert,fracDistVert,distChanges) <br>
%        </div>
% </html>
%
%% Description
% Assign default values for the random simulation settings and check
% if the provided user inputs are correct.
%
%% Input Arguments
%
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Npoints
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            number of initial points for which trajectories are
%            simulated
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            fracVert
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            fraction of random initial points corresponding to
%            vertices of the initial set (value in [0,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            fracDistVert
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            fraction of random disturbance values corresponding
%            to vertices of the disturbance set (value in [0,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            distChanges
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            number of changes of the disturbance values during
%            one time step of the algorithm (integer > 0)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Npoints
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            number of initial points for which trajectories are
%            simulated
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            fracVert
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            fraction of random initial points corresponding to
%            vertices of the initial set (value in [0,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            fracDistVert
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            fraction of random disturbance values corresponding
%            to vertices of the disturbance set (value in [0,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            distChanges
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            number of changes of the disturbance values during
%            one time step of the algorithm (integer > 0)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <simulateRandomhelp.html |simulateRandom|>
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
