%% zonoContainment
% solves the zonotope containment problem.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [isIn,vars] = zonoContainment(Zin,Zout,tol) <br>
%        </div>
% </html>
%
%% Description
% Given two zontopes Zin and Zout, this function checks whether Zin
% is contained in Zout using the conditions from [1, Corrolary 4]. In
% contrast to the function @zonotope/contains from the CORA toolbox,
% the values of the auxiliary varibales Gamma and gamma are available
% as well, e.g., to set an initial guess for nonlinear programming.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Zin
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            inbody
%            (class: zonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Zout
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            circumbody
%            (class: zonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            tol
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            tolerance for the containment check
%            (positive scalar)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            flagContains
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            true/false
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            vars
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            structure storing the auxiliary variables:
%            -.Gamma, gamma from [1, Eq. (15)]
%        </p>
%        <p class="table">
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="inner">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .slack
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            magnitude of the violation of the norm
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
%            condition in [1, Eq. (15)]
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('-') ->
%
%% References
% [1] S. Sadraddini and R. Tedrake, "Linear Encodings for Polytope
% Containment Problems," IEEE Conference on Decision and Control,
% 2019, pp. 4367-4372.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
