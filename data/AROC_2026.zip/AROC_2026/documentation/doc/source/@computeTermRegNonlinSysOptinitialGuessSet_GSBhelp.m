%% initialGuessSet_GSB
% computes an outer approximation of the minimal
% robust control invariant set of the linearized dynamics.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% minRCIset = initialGuessSet_GSB(obj,dynamics) <br>
%        </div>
% </html>
%
%% Description
% To obtain an initial guess for the optimization-based approaches
% for computing terminal regions of nonlinear systems, we compute an
% outer approximation of the minimal robust control invariant (RCI)
% set [1, Theorem 2]. The cost fuction is taken from [2, Sec. IV].
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysOpt
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dynamics
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class termRegNonlinSysDynamics
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            minRCIset
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            outer approximation of the minimal RCI set
%            (class: termRegNonlinSysLinApproach)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See also
% <matlab:doc('-') ->
%
%% References
% [1] K. Ghasemi et al. "Compositional synthesis via a convex
% parameterization of assume-guarantee contracts", 2020,
% Proceedings of the 23rd International Conference on Hybrid
% Systems: Computation and Control, Article No.: 16, pp. 1-10.
% [2] K. Ghasemi et al., "Compositional Synthesis of Decentralized
% Robust Set-Invariance Controllers for Large-scale Linear
% Systems," 2019, IEEE Conference on Decision and Control,
% pp. 2054-2059.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
