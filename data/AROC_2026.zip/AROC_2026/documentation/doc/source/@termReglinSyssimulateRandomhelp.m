%% simulateRandom
% simulate random trajectories of a linear system
% controlled with a safe set controller
%
%% Syntax
%
% <html>
%        <div class="syntax">
% trajectories = simulateRandom(obj, Npoints, sampleMethod) <br>
%        </div>
% </html>
%
%% Description
% Simulate trajectories of a linear time-invariant closed-loop system
% controlled with a terminal region controller corresponding to a
% terminal region computed with the linSysContainment algorithm for
% random initial points inside the terminal region and randomly drawn
% disturbance values.
%
%% Input Arguments
%
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Npoints
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            number of initial points for which trajectories
%            are simulated
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            samplingMethod
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            method used for sampling points, for example
%            <tt>'extreme'</tt> or 'uniform'
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            trajectories
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            cell with Npoints entries, each storing the data
%            of a simulated trajectory (see simulate.m)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('safeSets/simulateRandom') safeSets/simulateRandom>
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
