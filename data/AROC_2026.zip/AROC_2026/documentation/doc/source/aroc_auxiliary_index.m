%% Auxiliary

%% Directories
%
% * <.\@discretizeDynamics_index.html |@discretizeDynamics|>
% * <.\@extendedHorizonWeights_index.html |@extendedHorizonWeights|>
% * <.\@optimalControl_index.html |@optimalControl|>

%% Files
%
% * <.\RK2integratorhelp.html |RK2integrator|>
% * <.\RK4integratorhelp.html |RK4integrator|>
% * <.\centerTrajectoryhelp.html |centerTrajectory|>
% * <.\checkBooleanhelp.html |checkBoolean|>
% * <.\checkDoublehelp.html |checkDouble|>
% * <.\checkIntegerhelp.html |checkInteger|>
% * <.\checkMatrixhelp.html |checkMatrix|>
% * <.\checkOptshelp.html |checkOpts|>
% * <.\checkParamhelp.html |checkParam|>
% * <.\checkParametershelp.html |checkParameters|>
% * <.\checkStateConstraintshelp.html |checkStateConstraints|>
% * <.\checkStringhelp.html |checkString|>
% * <.\collisionCheckerhelp.html |collisionChecker|>
% * <.\compOccupancySethelp.html |compOccupancySet|>
% * <.\containsFasthelp.html |containsFast|>
% * <.\defaultSimulateRandomhelp.html |defaultSimulateRandom|>
% * <.\generateExpMathelp.html |generateExpMat|>
% * <.\getNameValuePairhelp.html |getNameValuePair|>
% * <.\getRedundantFieldshelp.html |getRedundantFields|>
% * <.\initOptshelp.html |initOpts|>
% * <.\initSearchDomainhelp.html |initSearchDomain|>
% * <.\innerApproxPolyhelp.html |innerApproxPoly|>
% * <.\isLinearModelhelp.html |isLinearModel|>
% * <.\parseOptshelp.html |parseOpts|>
% * <.\plotObstacleshelp.html |plotObstacles|>
% * <.\plotOccupancySethelp.html |plotOccupancySet|>
% * <.\postprocessingPolygonhelp.html |postprocessingPolygon|>
% * <.\projectReachSethelp.html |projectReachSet|>
% * <.\reachNonlinearhelp.html |reachNonlinear|>
% * <.\reachSetConformancehelp.html |reachSetConformance|>
% * <.\scaleZonoIntoZonohelp.html |scaleZonoIntoZono|>
% * <.\symLinearizehelp.html |symLinearize|>
% * <.\updateExtHorizonhelp.html |updateExtHorizon|>
% * <.\zonoContainmenthelp.html |zonoContainment|>

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
