%% termRegNonlinSysPolyApproach
% terminal region object computed with the
% polynomialization-based approach for computing terminal regions
% of nonlinear sytems.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% obj = termRegNonlinSysLinApproach(dynamics,set,ctrlSet,sysType,dt,U,W) <br>
%        </div>
% </html>
%
%% Description
% This class represents a terminal region computed using the
% polynomialization-based [1] approach for computing terminal region
% of nonlinear sytems.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dynamics
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            handle to the dynamics function of the nonlinear
%            system
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            set
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set representing the terminal region
%            (class: polyZonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            ctrlSet
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set representing the invariance-preserving control
%            law
%            (class: polyZonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            sysType
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            type of dynamical system must be a sampled-data
%            system
%            (class: termRegSysType)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dt
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            sampling time
%            (positive scalar)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            U
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of admissible control inputs
%            (class: zonotope / polytope / interval)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            W
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of disturbances
%            (class: zonotope / interval))
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            generated instance of the class
%            termRegNonlinSysPolyApproach
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('-') ->
%
%% References
% [1] L. Schäfer and M. Althoff, "Computing Robust Control
% Invariant Sets of Nonlinear Systems Using Polynomial
% Controller Synthesis," American Control Conference, 2024,
% pp. 4162-4169.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
