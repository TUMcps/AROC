%% reduceTemplate
% parameterized order reduction of the parameterized
% reachable set
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [R_next,mapsParamReduce] = reduceTemplate(obj,R_abs,R_err,candTermReg,candP,flagReduceFeasible) <br>
%        </div>
% </html>
%
%% Description
% To limit the number of optimization variables and constraints, the
% order of the parameterized reachable set has to be reduced.
% However, standard techniques for order reduction of (polynomial)
% zonotopes would drop the dependence of the reduced generators on
% the optimization variables. This function returns the reduced
% reachable set as well as maps for computing the edge lengths of the
% reducing set (box enclosing the reduced generators) as functions of
% the optimization variables. The reduced generators are enclosed by
% a box as in [2, Sec. 4]. If we want to ensure recursive feasibility
% (see [1, Sec. III-D], the number of reduced generators is chosen
% automatically so that the reduced reachable set R_next is contained
% in the candidate terminal region.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of the class
%            computeTermRegNonlinSysPolyApproach
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            R_abs
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            parameterized reachable set of the
%            abstraction
%            (class: polyZonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            R_err
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            approximation of the reachable set of
%            abstraction errors
%            (class: polyZonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            candTermReg
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            candidate terminal region
%            (class: polyZonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            candP
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            candidate controller parameters
%            (double vector)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            flagReduceFeasible
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            boolean indicating whether recursive
%            feasiblity shall be enforced for the
%            reduced reachable set or not
%            (logical)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             R_next
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            reduced approximation of the reachable set
%            (class: polyZonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             mapsParamReduce
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the maps for computing the
%            lengths of the reducing set's generators
%        </p>
%        <p class="table">
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="inner">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .dim
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            dimension (=number of parameterized;
%            reducing generators)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .c
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            dummy value to setup the function
%            handles for optimization
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .G
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            (polynomial) maps for computing the
%            scaling factors of the reducing
%            generators
%            (cell array of polyZonotopes)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .E
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            exponent matrix (ids in;
%            obj.id.termReg)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .idv
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            ids coresponding to .E
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .isConstGen
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            ith element is true if .G&#123;i&#125; is
%            independent of obj.id.var_scalar,
%            false otherwise
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .id
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            ids of reducing generators with
%            variable length
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .initScales
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            current length of the reducing
%            generators
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('-') ->
%
%% References
% [1] L. Schäfer and M. Althoff, "Computing Robust Control
% Invariant Sets of Nonlinear Systems Using Polynomial
% Controller Synthesis," American Control Conference, 2024,
% pp. 4162-4169.
% [2] A. Girard. "Reachability of uncertain linear systems using
% zonotopes", Hybrid Systems: Computation and Control, 2005,
% pp. 291–305.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
