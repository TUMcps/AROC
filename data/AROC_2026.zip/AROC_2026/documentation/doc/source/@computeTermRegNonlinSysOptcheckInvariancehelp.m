%% checkInvariance
% computes the reachable set of the dynamical system and
% checks whether the the terminal region is a robust control invariant set.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [flagInvariance,flagStateConstraints,b_tight] = checkInvariance(obj,dynamics,termReg) <br>
%        </div>
% </html>
%
%% Description
% This function is part of the verification procedure described in
% [1, Sec. III 2]: first over-approximations of the reachable sets
% are computed and, second, satisfaction of the constraints in [1,
% Eq. (6a), (6b)] / [2, Eq. (6b),(6c)] is checked. If the state
% constraint in [1, Eq. (6b)] / [2, Eq. (6c)] is violated, the
% difference of the support function of the reachable set in the
% violating direction A(j,:) and b(j) are computed (the set of
% admissible states is assumed to be represented as a polytope
% {x: A*x <= b}). This difference is used to tighten the set
% of admissible states in the next iteration of the verification
% procedure ({A*x <= b - b_tight}).
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysOpt
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dynamics
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class termRegNonlinSysDynamics
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            termReg
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            converged solution
%            (class: termRegNonlinSysOpt)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            flagInvariance
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            indicates satisfaction of the invariance
%            constraint in [1, Eq. 6a]
%            (class: logical)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            flagStateConstraints
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            indicates satisfaction of the state
%            constraint in [1, Eq. 6b]
%            (class: logical)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            b_tight
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            tightening vector for the state constraint
%            in [1, Eq. 6b]
%            (non-negative double vector)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('@computeTermRegNonlinSysOpt/verifyTerminalRegion') @computeTermRegNonlinSysOpt/verifyTerminalRegion>
%
%% References
% [1] L. Schäfer et al. "Scalable Computation of Robust Control
% Invariant Sets of Nonlinear Systems", in IEEE Transactions
% on Automatic Control, vol. 69, no. 2, pp. 755-770, 2024.
% [2] L. Schäfer and M. Althoff, "Computing Robust Control Invariant
% Sets of Nonlinear Systems Using Polynomial Controller
% Synthesis," American Control Conference, 2024, pp. 4162-4169.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
