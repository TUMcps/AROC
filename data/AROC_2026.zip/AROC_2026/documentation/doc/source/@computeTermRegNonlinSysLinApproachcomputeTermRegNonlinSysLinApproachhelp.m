%% computeTermRegNonlinSysLinApproach
% solver class for the
% linearization-based approach for computing terminal regions of
% nonlinear systems.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% obj = computeTermRegNonlinSysOpt(Param,Opts) <br>
%        </div>
% </html>
%
%% Description
% This class and its childclasses provide all methods required
% for formulating and solving the convex approximations of the
% terminal region optimization problem in [1, Sec. III] as well
% as the methods for verifying correctness of its solution.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Param
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            a struct containing the benchmark parameters
%            .X:         set of admissible states
%            (class: interval/zonotope/polytope)
%            .U:         set of admissible control inputs
%            (class: interval/zonotope/polytope)
%            .W:         set of disturbances
%            (class: zonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Opts
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            a struct containing the algorithm settings
%            .xEq:                   equlibrium state to be stabilized
%            (double vector)
%            .uEq:                   equilibrium control input
%            (double vector)
%            .termRegOrder:          (optional) order of the zonotope
%            representing the terminal region
%            (positive scalar, >= 1)
%            .verbose:               if set to true, the algorithm prints
%            information about each iteration to
%            the command window. If set to
%            false, no iterative output is shown.
%        </p>
%        <p class="table">
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="inner">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            solverSettings
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            (optional) struct storing the solver
%            settings, see superclass constructor
%            for shared fields
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            generated instance of the class
%            computeTermRegNonlinSysLinApproach
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('-') ->
%
%% References
% [1] L. Schäfer et al. "Scalable Computation of Robust Control
% Invariant Sets of Nonlinear Systems", in IEEE Transactions
% on Automatic Control, vol. 69, no. 2, pp. 755-770, 2024.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
