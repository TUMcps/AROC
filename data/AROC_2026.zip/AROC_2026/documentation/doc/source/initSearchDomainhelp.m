%% initSearchDomain
% initialize search domain for terminal region
%
%% Syntax
%
% <html>
%        <div class="syntax">
% Tdomain = initSearchDomain(K,xEq,uEq,U) <br>
% Tdomain = initSearchDomain(K,xEq,uEq,U,X) <br>
%        </div>
% </html>
%
%% Description
% Initialize the search domain for determining a terminal region
% using a heuristic that is based on the state and input constraints.
%
%% Input Arguments
%
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            K
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            feedback matrix for the controller
%            (dimension: [nu,nx])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            xEq
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            equilibrium point of the system
%            (dimension: [nx,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            uEq
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            control input for the equilibrium point
%            (dimension: [nu,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            U
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of control inputs
%            (class: interval or zonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            X
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of state constraints
%            (class: polytope)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Tdomain
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            search domain for the terminal region
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('computeTermRegZonoLinSys') computeTermRegZonoLinSys>, <matlab:doc('computeTermRegSubpaving') computeTermRegSubpaving>
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
