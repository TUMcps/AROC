%% computeDualInitialGuess
% computes an initial guess for the dual variables
% of the polynomial program.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [lam_g,lam_x] = computeDualInitialGuess(x0,cost_handle,con_handle,idxVars,idxCon,lbx,ubx) <br>
%        </div>
% </html>
%
%% Description
% This function computes an initial guess for the dual variables of
% the polynomial program in [1, Eq. (19)] by evaluating the KKT
% conditions at the primal initial guess x0 (thus, implicitly
% assuming that x0 is a stationary point).
% The polynomial program is formulated as in the CasADi
% documentation.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            x0
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            initial guess for the primal variables
%            (double array of dimension [idxVars.nVars,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            cost_handle
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            handle to the cost function of the polynomial
%            program
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            con_handle
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            handle to the constraint function of the polynomial
%            program (does not include variable bounds)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            idxVars
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the variable indices
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            idxCon
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the constraint indices
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            lbx
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            lower bound on the primal variables
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            ubx
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            upper bound on the primal variables
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            lam_x
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            initial guess for the Lagrange multipliers associated
%            with the variable bounds
%            (double array of dimension [idxVars.nVars,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            lam_g
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            initial guess for the Lagrange multipliers associated
%            with the constraints
%            (double array of dimension [idxCon.nCon,1])
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('@computeTermRegNonlinSysPolyApproach/optimizeRCIpoly') @computeTermRegNonlinSysPolyApproach/optimizeRCIpoly>
%
%% References
% [1] L. Schäfer and M. Althoff, "Computing Robust Control Invariant
% Sets of Nonlinear Systems Using Polynomial Controller
% Synthesis," American Control Conference, 2024, pp. 4162-4169.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
