%% setOptsInternal
% sets up all necessary 'primary' settings needed for the
% linSys algorithm
%
%% Syntax
%
% <html>
%        <div class="syntax">
% optsInternal = setOptsInternal(benchmark,Opts,Param) <br>
%        </div>
% </html>
%
%% Description
% This function sets up all necessary |'primary'| settings needed for
% the linSysContainment algorithm. This includes dedicated variables
% for the dynamics, some quantities needed for reachability analysis
% (in order to speed up the computation), as well as the system
% dimension etc.
% All these |'internal'| variables are saved in one big struct,
% optsInternal. In order to make it easier to track which variables
% are contained in the struct, and what they mean the actual
% initialization of the struct will be performed at the very end of
% this code, in the |'section'| called 'Struct Initialization'
%
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
