%% paramReach
% parameterized reachability analysis
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [R_next,mapsReduce] = paramReach(obj,dynamics,candTermReg,ctrl_template,candP,bloatAbsErr,flagReduceFeasible) <br>
%        </div>
% </html>
%
%% Description
% This function computes the time-point reachable set in [1, Eq.
% (17)]. This involves computing reachable sets of the abstraction
% using the polynomialization algorithm, computation of the
% abstraction error, and the parameterized order reduction to limit
% the number of variables and constraints in [1, Eq. (19)].
%
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysPolyApproach
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dynamics
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class termRegNonlinSysDynamics
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            candTermReg
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            candidate terminal region
%            (class: polyZonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            ctrl_template
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            controller template
%            (class: polyZonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            candP
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            candidate controller prarameters
%            (double array of dimension;
%            [length(obj.id.p),1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            bloatAbsErr
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            scaling factor for enlarging the set of
%            abstraction errors (see the  verification;
%            procedure described in [2, Sec. III 2])
%            (bloatAbsErr >= 1)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            flagReduceFeasible
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            true if the currenct candidate solution is
%            feasible, triggers adaptive order reduction,
%            see method reduceTemplate
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             Rfin
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            parameterized reachable set
%            (class: polyZonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             mapsReduce
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the ingredients for the
%            parameterized order reduction, see method
%            reduceTemplate
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('@computeTermRegNonlinSysPolyApproach/reduceTemplate') @computeTermRegNonlinSysPolyApproach/reduceTemplate>
%
%% References
% [1] L. Schäfer and M. Althoff, "Computing Robust Control
% Invariant Sets of Nonlinear Systems Using Polynomial
% Controller Synthesis," American Control Conference, 2024,
% pp. 4162-4169.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
