%% computeInitialGuess
% computes an inital guess for the
% polynomialization-based approach for computing terminal regions of
% nonlinear systems.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% initGuess = computeInitialGuess(obj,dynamics,Q,R,weights) <br>
%        </div>
% </html>
%
%% Description
% Computes an inital guess for the polynomialization-based approach
% for computing terminal regions of nonlinear systems [1]. The 7
% initial guess for the terminal region itself is obtained by
% computing different types of (robust) invariant sets of the
% linearized dynamics (around the equilibrium state) and combining
% their generators. To obtain an initial guess for the controller, we
% use generator space control [2].
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysPolyApproach
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dynamics
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class termRegNonlinSysDynamics
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Q
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            state weighting matrix
%            (positive-definite matrix of dimension;
%            [obj.nx,obj.nx])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            R
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            control input weighting matrix
%            (positive-definite matrix of dimension;
%            [obj.nu,obj.nu])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            weights
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the weights for computing
%            the initial guess
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            initGuess
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            initial guess for the terminal region and
%            controller
%            (class: termRegNonlinSysPolyApproach)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See also
% <matlab:doc('@computeTermRegNonlinSysOpt/initialGuessSet_RiccatiEq') @computeTermRegNonlinSysOpt/initialGuessSet_RiccatiEq>
% <matlab:doc('@computeTermRegNonlinSysOpt/initialGuessSet_GSB') @computeTermRegNonlinSysOpt/initialGuessSet_GSB>
% <matlab:doc('@computeTermRegNonlinSysOpt/initialGuessSet_mRPI') @computeTermRegNonlinSysOpt/initialGuessSet_mRPI>
%
%% References
% [1] L. Schäfer and M. Althoff, "Computing Robust Control Invariant
% Sets of Nonlinear Systems Using Polynomial Controller
% Synthesis," American Control Conference, 2024, pp. 4162-4169.
% [2] B. Schürmann and M. Althoff, "Guaranteeing Constraints of
% Disturbed Nonlinear Systems Using Set-Based Optimal Control in
% Generator Space,", IFAC-PapersOnLine, Volume 50, Issue 1, 2017,
% pp. 11515-11522.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
