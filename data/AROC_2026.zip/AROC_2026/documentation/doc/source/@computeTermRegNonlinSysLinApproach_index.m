%% @computeTermRegNonlinSysLinApproach

%% Files
%
% * <.\@computeTermRegNonlinSysLinApproachapproxAbsErrQuad_coefficientshelp.html |approxAbsErrQuad_coefficients|>
% * <.\@computeTermRegNonlinSysLinApproachapproxAbsErrQuad_evalhelp.html |approxAbsErrQuad_eval|>
% * <.\@computeTermRegNonlinSysLinApproachcomputeInitialGuesshelp.html |computeInitialGuess|>
% * <.\@computeTermRegNonlinSysLinApproachcomputeTermRegNonlinSysLinApproachhelp.html |computeTermRegNonlinSysLinApproach|>
% * <.\@computeTermRegNonlinSysLinApproachcomputeTrustRegionExploitationhelp.html |computeTrustRegionExploitation|>
% * <.\@computeTermRegNonlinSysLinApproachcvx_approxZonoVolumehelp.html |cvx_approxZonoVolume|>
% * <.\@computeTermRegNonlinSysLinApproachcvx_intervalTermReghelp.html |cvx_intervalTermReg|>
% * <.\@computeTermRegNonlinSysLinApproachcvx_paramReachSethelp.html |cvx_paramReachSet|>
% * <.\@computeTermRegNonlinSysLinApproachcvx_zonoContSoftConstrainthelp.html |cvx_zonoContSoftConstraint|>
% * <.\@computeTermRegNonlinSysLinApproachcvx_zonoInPolyConstrainthelp.html |cvx_zonoInPolyConstraint|>
% * <.\@computeTermRegNonlinSysLinApproachsolveOptProblemhelp.html |solveOptProblem|>

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
