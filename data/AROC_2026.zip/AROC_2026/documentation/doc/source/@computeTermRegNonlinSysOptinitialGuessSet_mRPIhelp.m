%% initialGuessSet_mRPI
% computes an (invariant) outer approximation of the
% minimal robust positively invariant set of the linearized dynamics.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% minRPIset = initialGuessSet_mRPI(obj,dynamics,Q,R) <br>
% minRPIset = initialGuessSet_mRPI(obj,dynamics,Q,R,flag_invariant) <br>
%        </div>
% </html>
%
%% Description
% To obtain an initial guess for the optimization-based approaches
% for computing terminal regions of nonlinear systems, we compute an
% outer approximation of the minimal robust positvely invariant
% (mRPI) set of the linearized dynamics (based on [1, Alg. 2]).
% By default, the loop in [1, Alg. 2, line 10-16] is omitted and the
% output order of initGuess is set to a user-defined value (see
% description of input arguments). If the additional input argument
% flag_invariant is set to true, this loop is executed.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysOpt
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dynamics
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class termRegNonlinSysDynamics
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Q
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            state weighting matrix
%            (positive-definite matrix of dimension;
%            [obj.nx,obj.nx])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            R
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            control input weighting matrix
%            (positive-definite matrix of dimension;
%            [obj.nu,obj.nu])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            flag_invariant
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            (optional), see description - if omitted or
%            false, the user-defined order is chosen as
%            opts.termRegOrder
%            (logical)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            minRPIset
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            outer approximation of the mRPI set
%            (class: termRegNonlinSysLinApproach)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See also
% <matlab:doc('-') ->
%
%% References
% [1] Gruber et al., "Computing safe sets of linear sampled-data
% systems", 2021, IEEE Control Systems Letter, vol. 5, no. 2,
% pp. 385-390.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
