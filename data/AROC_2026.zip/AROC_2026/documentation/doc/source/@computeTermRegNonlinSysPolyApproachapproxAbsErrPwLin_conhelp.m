%% approxAbsErrPwLin_con
% returns the (linear inequality) constraints
% encoding the piece-wise linear approximation of the abstraction error.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [cIneqStruct, cIneqStructAux] = approxAbsErrPwLin_con(obj,candTermReg,paramAbsErr_coefficients,idxVars) <br>
%        </div>
% </html>
%
%% Description
% This function returns the  (linear inequality) constraints
% encoding the piece-wise linear approximation of the abstraction
% error proposed in [1, Example 1].
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysPolyApproach
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            candTermReg
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            current candidate for the terminal
%            region
%            (polyZonotope/struct storing the;
%            parameters of a polyZonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            paramAbsErr_coefficients
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the coefficients of
%            the piece-wise linear approximation of
%            the abstraction error
%            .origin:    upper bound on the abstraction error at 0xUxW
%            (array of dimension [obj.nx,1])
%            .termReg:   upper bound on the abstraction error at
%            box(candTermReg)xUxW
%            (array of dimension [obj.nx,1])
%            .tr         upper bound on the abstraction error at
%            box(candTermReg+trust_region)xUxW
%            (array of dimension [obj.nx,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            idxVars
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the indices of the
%            optimization variables
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            cIneqStruct
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the matrix and right-hand
%            side of the linear inequality constraint
%            ensuring [1, Eq. (20b)]
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            cIneqStructAux
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the matrix and right-hand
%            side of the auxiliary linear inequality
%            constraints
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('@computeTermRegNonlinSysPolyApproach/approxAbsErrPwLin_coefficients') @computeTermRegNonlinSysPolyApproach/approxAbsErrPwLin_coefficients>
%
%% References
% [1] L. Schäfer and M. Althoff, "Computing Robust Control Invariant
% Sets of Nonlinear Systems Using Polynomial Controller
% Synthesis," American Control Conference, 2024, pp. 4162-4169.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
