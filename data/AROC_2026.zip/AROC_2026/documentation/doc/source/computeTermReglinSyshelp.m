%% computeTermReglinSys
% compute terminal region with
% linear system approach, using only containment
%
%% Syntax
%
% <html>
%        <div class="syntax">
% T = computeTermReglinSys(benchmark, Param, Opts) <br>
%        </div>
% </html>
%
%% Description
% This function computes a terminal region with the approach in [1]
% and [2].
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            benchmark
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            name of the considered benchmark model (see;
%            "aroc/benchmarks/dynamics/...")
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Param
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            a structure containing the benchmark parameters
%        </p>
%        <p class="table">
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="inner">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .U
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of admissible control inputs
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .W
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of uncertain disturbances
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .V
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of measurement noise
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .X
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of state constraints
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .Y
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of output constraints
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .Yexact
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of error-free output constraints
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .F<br> -.gamma
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            defines the output equation
%            y = x + Fv + gamma
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
%            U, X, and Y need to be polytopes, or will be transformed to
%            polytopes within the algorithm (i.e., intervals or zonotopes;
%            can also be used here, but will be transformed to polytopes).
%            W, V, and Ustart on the other hand need to be intervals or
%            zonotopes.
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             Opts
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            a structure containing the algorithm settings
%        </p>
%        <p class="table">
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="inner">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .N
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            number of time steps
%            [&#123;10&#125; / positive integer]
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .timeStep
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            sampling time [&#123;0.1&#125; / positive scalar]
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .terminalRegionType
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            method used for computing the terminal
%            region [&#123;<tt>'implicit'</tt>&#125; or <tt>'fixed'</tt>]
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .terminalRegionSet
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set type of the terminal region
%            [&#123;<tt>'zonotope'</tt>&#125; or <tt>'ellipsoid'</tt>]
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .taylorOrder
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            Taylor order for certain approximations
%            needed during the reachability analysis
%            [&#123;5&#125; / positive integer]
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .genMethod
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            method for computing the fixed directions
%            [&#123;<tt>'spherical'</tt>&#125; or <tt>'provided'</tt>]
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .nGenerators
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            if .genMethod=<tt>'spherical'</tt>, .nGenerators
%            should be the number of generators for
%            the fixed generator matrix
%            [&#123;dim(X)&#125;/ positive integer]
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .G
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            if .genMethod=<tt>'provided'</tt>, .matrix should
%            be the desired matrix for the fixed
%            generators
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .K
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            feedback matrix for the terminal
%            controller
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .Q
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            state weighting matrix for the LQR
%            approach applied to determine the
%            terminal controller
%            [&#123;eye(nx)&#125; / positive definite;
%            square matrix]
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            .R
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            input weighting matrix for the LQR
%            approach applied to determine the
%            terminal controller
%            [&#123;eye(nu)&#125; / positive definite;
%            square matrix]
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            T
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            object of class termRegContainmentLinSys
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <terminalRegionhelp.html |terminalRegion|>, <matlab:doc('termRegLinSysApproach') termRegLinSysApproach>
%
%% References
% * *[1] "Approximability of the Containment Problem for Zonotopes
% and Ellipsotopes", A. Kulmburg et al., submited to TAC
% in 2024
% * *[2] Gruber et al. (2021)*, Computing safe sets of linear
% sampled-data systems, IEEE Control Syst. Lett., vol. 5,
% no. 2, pp. 385-390

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
