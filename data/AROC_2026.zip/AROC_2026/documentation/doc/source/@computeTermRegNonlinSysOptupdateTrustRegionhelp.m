%% updateTrustRegion
% updates the trust region according to the strategy
% described in [1, Appendix II].
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [obj,tr_action] = updateTrustRegion(obj,auxData_iter,absErr_true) <br>
%        </div>
% </html>
%
%% Description
% This function updates the trust region according to the strategy
% described in [1, Appendix II].
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            updated instance of class
%            computeTermRegNonlinSysOpt
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            auxData_iter
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class termRegNonlinSysSolutionAuxData
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            absErr_true
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            set of abstraction errors for the optimal solution
%            (class: interval)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%             obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            updated instance of class
%            computeTermRegNonlinSysOpt
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            tr_action
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            string describing the modification of the trust
%            region
%            (<tt>'enlarge'</tt> / <tt>'no action'</tt> / <tt>'shrink'</tt>)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('-') ->
%
%% References
% [1] L. Schäfer et al. "Scalable Computation of Robust Control
% Invariant Sets of Nonlinear Systems", in IEEE Transactions
% on Automatic Control, vol. 69, no. 2, pp. 755-770, 2024
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
