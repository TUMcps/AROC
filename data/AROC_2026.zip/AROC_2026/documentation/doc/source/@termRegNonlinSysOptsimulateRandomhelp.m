%% simulateRandom
% simulate random trajectories of a nonlinear system
% controlled with a terminal region controller
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [res,t,x,u] = simulateRandom(obj,tFinal) <br>
% [res,t,x,u] = simulateRandom(obj,tFinal,Npoints,fracVert,fracDistVert,distChanges) <br>
%        </div>
% </html>
%
%% Description
% Simulate a trajectories of a nonlinear closed-loop system
% controlled with a terminal region controller corresponding to a
% zonotopic terminal region computed with the approaches from [1]/[2].
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class computeTermRegNonlinSysOpt
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            tFinal
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            final time for simulation
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            Npoints
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            number of initial points for which trajectories are
%            simulated
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            fracVert
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            fraction of random initial points corresponding to
%            vertices of the initial set (value in [0,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            fracDistVert
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            fraction of random disturbance values corresponding
%            to vertices of the disturbance set (value in [0,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            distChanges
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            number of changes of the disturbance values during
%            one time step of the algorithm (integer > 0)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            res
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            results object storing the simulation data
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            t
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            cell-array storing the vectors with the time points for all
%            simulated trajectories
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            x
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            cell-array storing the matrices with all simulated
%            trajectories
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            u
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            cell-array storing the applied control inputs for all
%            simulated trajectories
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('computeTerminalRegionNonlinSys') computeTerminalRegionNonlinSys>, <matlab:doc('computeTermRegNolinSysOptApproach') computeTermRegNolinSysOptApproach>
% <matlab:doc('@termRegNolinSysOptApproach/simulateRandom') @termRegNolinSysOptApproach/simulateRandom>
%
%% References
% [1] L. Schäfer et al., "Scalable Computation of Robust Control
% Invariant Sets of Nonlinear Systems", 2024, IEEE Transactions
% on Automatic Control, vol. 69, no. 2, pp. 755-770.
% [2] L. Schäfer and M. Althoff, "Computing Robust Control Invariant
% Sets of Nonlinear Systems Using Polynomial Controller
% Synthesis," American Control Conference, 2024, pp. 4162-4169.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
