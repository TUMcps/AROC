%% simulate
% simulate a trajectory of a terminal region controller
%
%% Syntax
%
% <html>
%        <div class="syntax">
% [res,t,xSim,uSim] = simulate(obj,x0,tFinal,w) <br>
%        </div>
% </html>
%
%% Description
% Simulate a trajectory of a linear closed-loop system controlled
% with the terminal region controller corresponding to a terminal
% region computed with the zonotope approach for linear systems.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class computeTermRegNonlinSysOpt
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            x0
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            initial state for simulation
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            tFinal
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            final time for simulation
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            w
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            array storing the disturbance trajectory
%            (double arry of dimension: [nw,timeSteps])
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            res
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            results object storing the simulation data
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            t
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            vector storing the time points for the simulated states
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            xSim
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            array storing the simulated trajectory
%            (double array of dimension: [<tt>t</tt>,nx])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            uSim
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            array storing the applied control input
%            (double array of dimension: [<tt>t</tt>,nu])
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('computeTerminalRegionNonlinSys') computeTerminalRegionNonlinSys>, <matlab:doc('computeTermRegNolinSysOptApproach') computeTermRegNolinSysOptApproach>
% <matlab:doc('@termRegNolinSysOptApproach/simulateRandom') @termRegNolinSysOptApproach/simulateRandom>
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
