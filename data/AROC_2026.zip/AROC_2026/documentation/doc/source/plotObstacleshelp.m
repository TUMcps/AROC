%% plotObstacles
% plot static and dynamic obstacles
%
%% Syntax
%
% <html>
%        <div class="syntax">
% plotObstacles(statObs) <br>
% plotObstacles(statObs,dynObs,time) <br>
% plotObstacles(statObs,dynObs,time,color,options) <br>
%        </div>
% </html>
%
%% Description
% Plot static and dynamic obstacles for the given time frame.
%
%% Input Arguments
%
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            statObs
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            cell-array storing the static obstacles
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dynObs
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            cell-array storing the dynamic obstacles. Each dynamic
%            obstacle is represented as a struct with fields .set
%            and .time
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            time
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            time interval for which the trajectory is plotted
%            (class: interval)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            color
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            color for the plot specified as a string (e.g. <tt>'r'</tt>) or
%            as a vector of RGB-values (e.g. [0 1 0])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            options
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            additional MATLAB plot options specified as name-value
%            pairs (e.g. <tt>'LineWidth'</tt>,2)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <animatehelp.html |animate|>
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
