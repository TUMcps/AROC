%% Automaton

%% Files
%
% * <.\postprocessing_carhelp.html |postprocessing_car|>
% * <.\postprocessing_mobileRobothelp.html |postprocessing_mobileRobot|>
% * <.\postprocessing_quadrotor2Dhelp.html |postprocessing_quadrotor2D|>
% * <.\postprocessing_robotArmhelp.html |postprocessing_robotArm|>
% * <.\postprocessing_shiphelp.html |postprocessing_ship|>
% * <.\postprocessing_truckhelp.html |postprocessing_truck|>
% * <.\shiftInitSet_carhelp.html |shiftInitSet_car|>
% * <.\shiftInitSet_mobileRobothelp.html |shiftInitSet_mobileRobot|>
% * <.\shiftInitSet_quadrotor2Dhelp.html |shiftInitSet_quadrotor2D|>
% * <.\shiftInitSet_robotArmhelp.html |shiftInitSet_robotArm|>
% * <.\shiftInitSet_shiphelp.html |shiftInitSet_ship|>
% * <.\shiftInitSet_truckhelp.html |shiftInitSet_truck|>
% * <.\shiftOccupancySet_carhelp.html |shiftOccupancySet_car|>
% * <.\shiftOccupancySet_mobileRobothelp.html |shiftOccupancySet_mobileRobot|>
% * <.\shiftOccupancySet_quadrotor2Dhelp.html |shiftOccupancySet_quadrotor2D|>
% * <.\shiftOccupancySet_robotArmhelp.html |shiftOccupancySet_robotArm|>
% * <.\shiftOccupancySet_shiphelp.html |shiftOccupancySet_ship|>
% * <.\shiftOccupancySet_truckhelp.html |shiftOccupancySet_truck|>

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
