%% RK4integrator
% implements the classical Runge-Kutta scheme (aka RK4).
%
%% Syntax
%
% <html>
%        <div class="syntax">
% xNext = RK4integrator(x,u,w,funHandle,dt) <br>
%        </div>
% </html>
%
%% Description
% This function implements the classical Runge-Kutta scheme and, in
% addition to solving the initial value problem
% x_dot = f(x,u,w),  x(0) = x0
% numerically, can be used for time-discretizing continuous-time
% dynamical systems, e.g. for reachability analysis using CORA. Both
% the control input "u" and the disturbance "w" are assumed to be
% constant during the time step.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            x0
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            initial state
%            (real array of dimension [nx,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            u
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            control input
%            (real array of dimension [nu,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            w
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            disturbance
%            (real array of dimension [nw,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            funHandle
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            function handle to the dynamics function of the
%            continuous-time system
%            (x_dot = f(x,u,w);
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dt
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            time step
%            (positive scalar)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            xNext
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            state at the end of the time interval [0, dt]
%            (real array of dimension [nx,1])
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('-') ->
%
%% References
% [1] W. Kutta, "Beitrag zur näherungsweisen Integration totaler
% Differentialgleichungen", Zeitschrift für Mathematik
% und Physik, 46: 435–453, 1901.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
