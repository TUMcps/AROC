%% approxAbsErrPwLin_eval
% evaluation function for the piece-wise linear
% approximation of the abstraction error.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% approxAbsErr = approxAbsErrPwLin_eval(obj,candTermReg_sc,s,delta_c,paramAbsErr_coefficients) <br>
%        </div>
% </html>
%
%% Description
% This function returns the value of the piece-wise linear
% approximation of the abstraction error proposed in [1, Example 1].
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysPolyApproach
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            candTermReg_sc
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            parameterized candidate terminal region
%            (center and generator scaling factors)
%            (polyZonotope/struct storing the;
%            parameters of a polyZonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            s
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            generator scaling factors for the
%            candidate terminal region
%            (double vector)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            delta_c
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            center translation for the canddiate
%            terminal region
%            (array of dimension [obj.nx,1])
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            paramAbsErr_coefficients
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the coefficients of
%            the piece-wise linear approximation of
%            the abstraction error
%            .origin:    upper bound on the abstraction error at 0xUxW
%            (array of dimension [obj.nx,1])
%            .termReg:   upper bound on the abstraction error at
%            box(candTermReg)xUxW
%            (array of dimension [obj.nx,1])
%            .tr         upper bound on the abstraction error at
%            box(candTermReg+trust_region)xUxW
%            (array of dimension [obj.nx,1])
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            approxAbsErr
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            (lower bound of) abstraction error approximation
%            (non-negative array of dimension [obj.nx,1])
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('@computeTermRegNonlinSysPolyApproach/approxAbsErrPwLin_coefficients') @computeTermRegNonlinSysPolyApproach/approxAbsErrPwLin_coefficients>
% <matlab:doc('@computeTermRegNonlinSysPolyApproach/approxAbsErrPwLin_con') @computeTermRegNonlinSysPolyApproach/approxAbsErrPwLin_con>
%
%% References
% [1] L. Schäfer and M. Althoff, "Computing Robust Control Invariant
% Sets of Nonlinear Systems Using Polynomial Controller
% Synthesis," American Control Conference, 2024, pp. 4162-4169.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
