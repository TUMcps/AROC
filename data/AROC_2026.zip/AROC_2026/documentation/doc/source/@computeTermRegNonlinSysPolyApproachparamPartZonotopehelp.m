%% paramPartZonotope
% wrapper for computing a partial zonotope
% over-approximation of the reachable set.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% partZono = computeTermRegNonlinSysPolyApproach.paramPartZonotope(pZ,idv,idp) <br>
%        </div>
% </html>
%
%% Description
% This function computes a partial zonotope over-approximation of a
% given polynomial zonotope pZ in the ids stored in idv (which
% include the generator scaling factors). Since we scale the
% generators of the initial set during optimization, we cannot use
% the partZonotope method of the polyZonotope class, which ignores
% the dependance of the center of pZ on the scaling factors.
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            pZ
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            parameterized reachable set
%            (class: polyZonotope)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            idv
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            vector of ids for over-approximation (interval-valued;
%            factors like generator scaling factors)
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            idp
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            vector of ids of scalar-valued factors like the
%            controller parameters
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
% partZono:   struct storing the components of the partial
% zonotope over-approximation of pZ:
% .c: center - does not include contributions by
% generators with exlusively even exponents in idv
% (class: polyZonotope)
% .G: generators
% (class: cell array of polyZonotopes)
% .E: exponent matrix of factors with id in idv
% (integer array of dimension [length(idv,
% length(partZono.G)])
% .isConstGen: logical vector indicating whether
% partZono{i}.G is indepdendent (true) of ids in idp
% or not (false)
% (logical vector of length length(partZono.G))
% .cVar: logical vector indicating whether partZono{i}.G
% has exclusively even exponents in idv (true -
% contributes to the center of the re-assembled
% polyZonotope) or not (false)
% (logical vector of length length(partZono.G))
% .idv: ids of interval-valued factors like generator
% scaling factors)
%
%% See Also
% <matlab:doc('-') ->
%
%% References
% [1] L. Schäfer and M. Althoff, "Computing Robust Control Invariant
% Sets of Nonlinear Systems Using Polynomial Controller
% Synthesis," American Control Conference, 2024, pp. 4162-4169.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
