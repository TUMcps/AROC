%% approxAbsErrPwLin_coefficients
% computes the coefficients of the
% piece-wise linear approximation of the abstraction error.
%
%% Syntax
%
% <html>
%        <div class="syntax">
% coefficients = approxAbsErrPwLin_coefficients(obj,dynamics,candTermReg) <br>
%        </div>
% </html>
%
%% Description
% This function computes the semi-edge lengths of an interval
% enclosing the abstraction error (conservative polynomialization
% algorithm with tensor order 3). These serve as the coefficients of
% the piece-wise linear approximation of the abstraction error
% proposed in [1, Example 1].
%
%% Input Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            obj
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class
%            computeTermRegNonlinSysPolyApproach
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            dynamics
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            instance of class termRegNonlinSysDynamics
%        </p>
%    </td>
%    </tr>
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            candTermReg
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            current candidate for the terminal region
%            (class: polyZonotope)
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% Output Arguments
%
% <html>
% <table cellspacing="0" cellpadding="4" width="" border="1" frame="box" rules="none" class="">
% <tbody valign="top">
%    <tr bgcolor="#F2F2F2">
%    <td>
%        <p class="table">
%            coefficients
%        </p>
%    </td>
%    <td>
%        <p class="table">
%            struct storing the coefficients of the piece-
%            wise linear approximation of the abstraction error
%            .origin:    upper bound on the abstraction error at 0xUxW
%            (array of dimension [obj.nx,1])
%            .termReg:   upper bound on the abstraction error at
%            box(candTermReg)xUxW
%            (array of dimension [obj.nx,1])
%            .tr         upper bound on the abstraction error at
%            box(candTermReg+trust_region)xUxW
%            (array of dimension [obj.nx,1])
%        </p>
%    </td>
%    </tr>
% </tbody>
% </table>
% </html>
%
%% See Also
% <matlab:doc('@computeTermRegNonlinSysPolyApproach/approxAbsErrPwLin_con') @computeTermRegNonlinSysPolyApproach/approxAbsErrPwLin_con>
%
%% References
% [1] L. Schäfer and M. Althoff, "Computing Robust Control Invariant
% Sets of Nonlinear Systems Using Polynomial Controller
% Synthesis," American Control Conference, 2024, pp. 4162-4169.
%

%%
% <html>
%   <hr>
%   <p class="copy">&copy; 2018-2026 I6 Technische Universit&auml;t M&uuml;nchen
%        <tt class="minicdot">&#149;</tt>
%        <a href="https://tumcps.github.io/AROC/">Website</a>
%        <tt class="minicdot">&#149;</tt>
%        <a href="file:txts/LICENSE.txt">License</a>
%   </p>
% <div>
% <table>
%  <tr>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%             <img src="img/logoAroc.png" alt="logoAroc" height="40px">
%      </td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoCora.png" alt="logoCora" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoChair.png" alt="logoChair" height="40px"></td>
%   <td style="background-color:#ffffff; border:0; width:25%; vertical-align:middle; text-align:center">
%      <img src="img/logoTum.png" alt="logoTum" height="40px"></td>
%  </tr>
% </table>
% </div>
% </html>
